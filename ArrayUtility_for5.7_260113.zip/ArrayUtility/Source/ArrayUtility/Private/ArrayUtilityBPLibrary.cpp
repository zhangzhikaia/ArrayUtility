// Copyright lurongjiu 2026 All Rights Reserved.

#include "ArrayUtilityBPLibrary.h"
#include "ArrayUtility.h"

/*
 * 需确保变量名保持一致,分别为:
 * ArrayProp,ArrayAddr,OutArrayProp,OutArrayAddr,SourceHelper,DestHelper,Count
 */
#define ARRAY_THUNK_GET_ARRAY \
Stack.MostRecentProperty = nullptr; \
Stack.Step(Stack.Object, nullptr); \
FArrayProperty* ArrayProp = CastField<FArrayProperty>(Stack.MostRecentProperty); \
void* ArrayAddr = Stack.MostRecentPropertyAddress;

#define ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr) \
Stack.MostRecentProperty = nullptr; \
Stack.Step(Stack.Object, nullptr); \
FArrayProperty* OutArrayProp = CastField<FArrayProperty>(Stack.MostRecentProperty); \
void* OutArrayAddr = Stack.MostRecentPropertyAddress;

#define INITIAL_AND_SAFE_CHECK \
if (!ArrayProp || !OutArrayProp)\
{\
return;\
}\
FScriptArrayHelper SourceHelper(ArrayProp, ArrayAddr);\
FScriptArrayHelper DestHelper(OutArrayProp, OutArrayAddr);\
DestHelper.EmptyValues();\
if(Count <= 0 || SourceHelper.Num() <= 0)\
{\
UE_LOG(LogTemp, Warning, TEXT("Count <= 0 or source array empty, returning empty array."));\
return;\
}


UArrayUtilityBPLibrary::UArrayUtilityBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
}

// 普通 C++ 路径（Blueprint 不会走这里）
void UArrayUtilityBPLibrary::GetFirstX(const TArray<int32>& TargetArray, int32 Count,TArray<int32>& OutArray){}

void UArrayUtilityBPLibrary::GetLastX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray){}

void UArrayUtilityBPLibrary::GetMidX(const TArray<int32>& TargetArray, int32 StartIndex, int32 Count,TArray<int32>& OutArray){}

void UArrayUtilityBPLibrary::GetRandomX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray){}

void UArrayUtilityBPLibrary::GetRandomXFromStream(const TArray<int32>& TargetArray, UPARAM(ref) FRandomStream& RandomStream,int32 Count, TArray<int32>& OutArray){}

void UArrayUtilityBPLibrary::SplitArray(const TArray<int32>& TargetArray, int32 SplitIndex, TArray<int32>& OutFront,TArray<int32>& OutBack){}

void UArrayUtilityBPLibrary::RemoveFirstX(TArray<int32>& TargetArray, int32 Count){}

void UArrayUtilityBPLibrary::RemoveLastX(TArray<int32>& TargetArray, int32 Count){}

void UArrayUtilityBPLibrary::PopRandomX(TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray){}

void UArrayUtilityBPLibrary::PopRandomXFromStream(TArray<int32>& TargetArray, UPARAM(ref) FRandomStream& RandomStream, int32 Count,TArray<int32>& OutArray){}

// 不会被 Blueprint 调用

// Blueprint VM 调用路径
DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetFirstX)
{
	ARRAY_THUNK_GET_ARRAY
	
	P_GET_PROPERTY(FIntProperty, Count);

	ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)
	
	P_FINISH;

	INITIAL_AND_SAFE_CHECK
	
    const int32 Num = SourceHelper.Num();
	const int32 RealCount = FMath::Clamp(Count, 0, Num);
	
    // ===== 逐个复制前 X 个元素 =====
    for (int32 i = 0; i < RealCount; ++i)
    {
        const int32 NewIndex = DestHelper.AddValue();
    	
        ArrayProp->Inner->CopyCompleteValue(
            DestHelper.GetRawPtr(NewIndex),
            SourceHelper.GetRawPtr(i)
        );
    }
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetLastX)
{
	ARRAY_THUNK_GET_ARRAY
	
	P_GET_PROPERTY(FIntProperty, Count);

	ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)
	
	P_FINISH;

	INITIAL_AND_SAFE_CHECK

	const int32 Num = SourceHelper.Num();
	const int32 RealCount = FMath::Clamp(Count, 0, Num);
	const int32 StartIndex = Num - RealCount;

	for (int32 i = StartIndex; i < Num; ++i)
	{
		const int32 NewIndex = DestHelper.AddValue();
		ArrayProp->Inner->CopyCompleteValue(
			DestHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(i)
		);
	}
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetMidX)
{
	// ===== TargetArray =====
	ARRAY_THUNK_GET_ARRAY

	// ===== StartIndex =====
	P_GET_PROPERTY(FIntProperty, StartIndex);

	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	// ===== OutArray =====
	ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)

	P_FINISH;

	// ===== Safety =====
	INITIAL_AND_SAFE_CHECK
	
	const int32 Num = SourceHelper.Num();
	
	const int32 RealStartIndex = FMath::Clamp(StartIndex, 0, Num);
	const int32 MaxCopyCount   = Num - RealStartIndex;
	const int32 RealCount      = FMath::Clamp(Count, 0, MaxCopyCount);

	// ======================================================
	// 拷贝 [RealStartIndex, RealStartIndex + RealCount)
	// ======================================================
	for (int32 i = 0; i < RealCount; ++i)
	{
		const int32 SrcIndex = RealStartIndex + i;
		const int32 NewIndex = DestHelper.AddValue();

		ArrayProp->Inner->CopyCompleteValue(
			DestHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(SrcIndex)
		);
	}
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetRandomX)
{
	ARRAY_THUNK_GET_ARRAY
	
	P_GET_PROPERTY(FIntProperty, Count);

	ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)
	
	P_FINISH;

	INITIAL_AND_SAFE_CHECK

	const int32 Num = SourceHelper.Num();
	const int32 RealCount = FMath::Clamp(Count, 0, Num);

	if (RealCount <= 0)
	{
		return;
	}

	/* 生成 index 池 */
	TArray<int32> Indices;
	Indices.Reserve(Num);
	for (int32 i = 0; i < Num; ++i)
	{
		Indices.Add(i);
	}

	/* Fisher–Yates Shuffle（只洗前 X 次也行，这里全洗，清晰优先） */
	for (int32 i = Num - 1; i > 0; --i)
	{
		const int32 SwapIndex = FMath::RandRange(0, i);
		Indices.Swap(i, SwapIndex);
	}

	/* 拷贝前 RealCount 个 */
	for (int32 i = 0; i < RealCount; ++i)
	{
		const int32 SrcIndex = Indices[i];
		const int32 NewIndex = DestHelper.AddValue();

		ArrayProp->Inner->CopyCompleteValue(
			DestHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(SrcIndex)
		);
	}
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetRandomXFromStream)
{
	// ===== TargetArray =====
	ARRAY_THUNK_GET_ARRAY

	// ===== RandomStream =====
	P_GET_STRUCT_REF(FRandomStream, RandomStream);

	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	// ===== OutArray =====
	ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)

	P_FINISH;

	// ===== Safety =====
	INITIAL_AND_SAFE_CHECK
	
	const int32 Num = SourceHelper.Num();
	const int32 RealCount = FMath::Clamp(Count, 0, Num);

	// ======================================================
	// 生成索引池
	// ======================================================
	TArray<int32> Indices;
	Indices.Reserve(Num);
	for (int32 i = 0; i < Num; ++i)
	{
		Indices.Add(i);
	}

	// ======================================================
	// Fisher–Yates Shuffle（使用 RandomStream）
	// ======================================================
	for (int32 i = Num - 1; i > 0; --i)
	{
		const int32 SwapIndex = RandomStream.RandRange(0, i);
		Indices.Swap(i, SwapIndex);
	}

	// ======================================================
	// 拷贝前 RealCount 个
	// ======================================================
	for (int32 i = 0; i < RealCount; ++i)
	{
		const int32 SrcIndex = Indices[i];
		const int32 NewIndex = DestHelper.AddValue();

		ArrayProp->Inner->CopyCompleteValue(
			DestHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(SrcIndex)
		);
	}
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execSplitArray)
{
	// ===== TargetArray =====
	ARRAY_THUNK_GET_ARRAY

	// ===== SplitIndex =====
	P_GET_PROPERTY(FIntProperty, SplitIndex);

	// ===== OutFront =====
	ARRAY_THUNK_GET_OUT_ARRAY(OutFrontProp, OutFrontAddr);

	// ===== OutBack =====
	ARRAY_THUNK_GET_OUT_ARRAY(OutBackProp, OutBackAddr);

	P_FINISH;

	// ===== Safety =====
	if (!ArrayProp || !OutFrontProp || !OutBackProp)
	{
		return;
	}

	FScriptArrayHelper SourceHelper(ArrayProp, ArrayAddr);
	FScriptArrayHelper FrontHelper(OutFrontProp, OutFrontAddr);
	FScriptArrayHelper BackHelper(OutBackProp, OutBackAddr);

	FrontHelper.EmptyValues();
	BackHelper.EmptyValues();

	const int32 Num = SourceHelper.Num();
	if (Num <= 0)
	{
		return;
	}

	const int32 RealSplitIndex = FMath::Clamp(SplitIndex, 0, Num);

	// ======================================================
	// 前半部分 [0, RealSplitIndex)
	// ======================================================
	for (int32 i = 0; i < RealSplitIndex; ++i)
	{
		const int32 NewIndex = FrontHelper.AddValue();

		ArrayProp->Inner->CopyCompleteValue(
			FrontHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(i)
		);
	}

	// ======================================================
	// 后半部分 [RealSplitIndex, Num)
	// ======================================================
	for (int32 i = RealSplitIndex; i < Num; ++i)
	{
		const int32 NewIndex = BackHelper.AddValue();

		ArrayProp->Inner->CopyCompleteValue(
			BackHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(i)
		);
	}
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execRemoveFirstX)
{
	// ===== TargetArray =====
	ARRAY_THUNK_GET_ARRAY

	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	P_FINISH;

	if (!ArrayProp || Count <= 0)
	{
		return;
	}

	FScriptArrayHelper ArrayHelper(ArrayProp, ArrayAddr);

	const int32 Num = ArrayHelper.Num();
	if (Num <= 0)
	{
		return;
	}

	const int32 RemoveCount = FMath::Clamp(Count, 0, Num);

	// ======================================================
	// 移除 [0, RemoveCount)
	// ======================================================
	ArrayHelper.RemoveValues(0, RemoveCount);
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execRemoveLastX)
{
	// ===== TargetArray =====
	ARRAY_THUNK_GET_ARRAY

	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	P_FINISH;

	if (!ArrayProp || Count <= 0)
	{
		return;
	}

	FScriptArrayHelper ArrayHelper(ArrayProp, ArrayAddr);

	const int32 Num = ArrayHelper.Num();
	if (Num <= 0)
	{
		return;
	}

	const int32 RemoveCount = FMath::Clamp(Count, 0, Num);
	const int32 StartIndex = Num - RemoveCount;

	// ======================================================
	// 移除 [StartIndex, Num)
	// ======================================================
	ArrayHelper.RemoveValues(StartIndex, RemoveCount);
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execPopRandomX)
{
	// ===== TargetArray =====
	ARRAY_THUNK_GET_ARRAY

	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	// ===== OutArray =====
	ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)

	P_FINISH;

	INITIAL_AND_SAFE_CHECK

	const int32 Num = SourceHelper.Num();

	const int32 RealCount = FMath::Clamp(Count, 0, Num);

	// ======================================================
	// 生成索引池
	// ======================================================
	TArray<int32> Indices;
	Indices.Reserve(Num);
	for (int32 i = 0; i < Num; ++i)
	{
		Indices.Add(i);
	}

	// ======================================================
	// Fisher–Yates Shuffle
	// ======================================================
	for (int32 i = Num - 1; i > 0; --i)
	{
		const int32 SwapIndex = FMath::RandRange(0, i);
		Indices.Swap(i, SwapIndex);
	}

	// ======================================================
	// 先 Pop（拷贝）被移除元素
	// ======================================================
	for (int32 i = 0; i < RealCount; ++i)
	{
		const int32 SrcIndex = Indices[i];
		const int32 NewIndex = DestHelper.AddValue();

		ArrayProp->Inner->CopyCompleteValue(
			DestHelper.GetRawPtr(NewIndex),
			SourceHelper.GetRawPtr(SrcIndex)
		);
	}

	// ======================================================
	// 再删除（必须从大到小）
	// ======================================================
	Indices.SetNum(RealCount);
	//Indices.Sort(TGreater<int32>());
	Indices.Sort([](int32 A, int32 B)
	{
		return A > B;
	});
	
	for (int32 Index : Indices)
	{
		SourceHelper.RemoveValues(Index, 1);
	}
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execPopRandomXFromStream)
{
    // ===== TargetArray =====
    ARRAY_THUNK_GET_ARRAY

    // ===== RandomStream =====
    P_GET_STRUCT_REF(FRandomStream, RandomStream);

    // ===== Count =====
    P_GET_PROPERTY(FIntProperty, Count);

    // ===== OutArray =====
    ARRAY_THUNK_GET_OUT_ARRAY(OutArrayProp,OutArrayAddr)

    P_FINISH;

	INITIAL_AND_SAFE_CHECK

    const int32 Num = SourceHelper.Num();

    const int32 RealCount = FMath::Clamp(Count, 0, Num);

    // ======================================================
    // 索引池
    // ======================================================
    TArray<int32> Indices;
    Indices.Reserve(Num);
    for (int32 i = 0; i < Num; ++i)
    {
        Indices.Add(i);
    }

    // ======================================================
    // Shuffle（By Stream）
    // ======================================================
    for (int32 i = Num - 1; i > 0; --i)
    {
        const int32 SwapIndex = RandomStream.RandRange(0, i);
        Indices.Swap(i, SwapIndex);
    }

    // ======================================================
    // Pop
    // ======================================================
    for (int32 i = 0; i < RealCount; ++i)
    {
        const int32 SrcIndex = Indices[i];
        const int32 NewIndex = DestHelper.AddValue();

        ArrayProp->Inner->CopyCompleteValue(
            DestHelper.GetRawPtr(NewIndex),
            SourceHelper.GetRawPtr(SrcIndex)
        );
    }

    // ======================================================
    // Remove（降序）
    // ======================================================
    Indices.SetNum(RealCount);
    /*Indices.Sort(TGreater<int32>());*/
	Indices.Sort([](int32 A, int32 B)
	{
		return A > B;
	});
	
    for (int32 Index : Indices)
    {
        SourceHelper.RemoveValues(Index, 1);
    }
}