// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "ArrayUtilityBPLibrary.generated.h"


UCLASS()
class UArrayUtilityBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()
	
	/**
	* Get first X elements from an array
	*
	* @param TargetArray   Source array
	* @param Count         Number of elements to get
	* @param OutArray      Output array containing the first X elements
	*/
    UFUNCTION(BlueprintCallable, CustomThunk,Category = "Array|Utility", meta = (DisplayName = "Get First X", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "FirstX"))
    static void GetFirstX(const TArray<int32>& TargetArray, int32 Count,TArray<int32>& OutArray);

	/**
	* Get last X elements from an array
	*
	* @param TargetArray   Source array
	* @param Count         Number of elements to get
	* @param OutArray      Output array containing the last X elements
	*/
    UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Get Last X", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "LastX"))
    static void GetLastX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray);

	/**
	* Get mid X elements from an array
	*
	* @param TargetArray   Source array
	* @param StartIndex    Start from index
	* @param Count         Number of elements to get
	* @param OutArray      Output array containing the mid X elements
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Get Mid X", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "MidX"))
	static void GetMidX(const TArray<int32>& TargetArray,int32 StartIndex, int32 Count,TArray<int32>& OutArray);
	
	/**
	* Get random X elements from an array
	*
	* @param TargetArray   Source array
	* @param Count         Number of elements to get
	* @param OutArray      Output array containing the random X elements
	*/
    UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Get Random X", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "RandX"))
    static void GetRandomX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray);

	/**
	* Get random X elements from an array from stream
	*
	* @param TargetArray   Source array
	* @param RandomStream  Random stream
	* @param Count         Number of elements to get
	* @param OutArray      Output array containing the random X elements
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Get Random X From Stream", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "RandX(S)"))
	static void GetRandomXFromStream(const TArray<int32>& TargetArray,UPARAM(ref) FRandomStream& RandomStream,int32 Count,TArray<int32>& OutArray);

	/**
	* Split array from index
	*
	* @param TargetArray   Source array
	* @param SplitIndex    Split index ( == OutFront.Num )
	* @param OutFront      Out front
	* @param OutBack       Out back
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Split Array", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutFront,OutBack", CompactNodeTitle = "Split"))
	static void SplitArray(const TArray<int32>& TargetArray,int32 SplitIndex, TArray<int32>& OutFront,TArray<int32>& OutBack);

	/**
	* Remove first X elements from an array
	*
	* @param TargetArray   Source array
	* @param Count         Number of elements to remove
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Remove First X", ArrayParm = "TargetArray", CompactNodeTitle = "RemFirstX"))
	static void RemoveFirstX(UPARAM(ref) TArray<int32>& TargetArray,int32 Count);

	/**
	* Remove last X elements from an array
	*
	* @param TargetArray   Source array
	* @param Count         Number of elements to remove
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Remove Last X", ArrayParm = "TargetArray", CompactNodeTitle = "RemLastX"))
	static void RemoveLastX(UPARAM(ref) TArray<int32>& TargetArray,	int32 Count);

	/**
	* Pop random X elements from an array
	*
	* @param TargetArray   Source array
	* @param Count         Number of elements to pop
	* @param OutArray      Output array containing the random X elements
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Pop Random X", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "PopRandX"))
	static void PopRandomX(UPARAM(ref) TArray<int32>& TargetArray,int32 Count,TArray<int32>& OutArray);

	/**
	* Pop random X elements from an array from stream
	*
	* @param TargetArray   Source array
	* @param RandomStream  Random stream
	* @param Count         Number of elements to pop
	* @param OutArray      Output array containing the random X elements
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility", meta = (DisplayName = "Pop Random X (By Stream)", ArrayParm = "TargetArray", ArrayTypeDependentParams = "OutArray", CompactNodeTitle = "PopRandX(S)"))
	static void PopRandomXFromStream(UPARAM(ref) TArray<int32>& TargetArray,UPARAM(ref) FRandomStream& RandomStream,int32 Count,TArray<int32>& OutArray);
	
	
    /* ===== Custom Thunks ===== */
    DECLARE_FUNCTION(execGetFirstX);
    DECLARE_FUNCTION(execGetLastX);
	DECLARE_FUNCTION(execGetMidX);
    DECLARE_FUNCTION(execGetRandomX);
	DECLARE_FUNCTION(execGetRandomXFromStream);
	DECLARE_FUNCTION(execSplitArray);
	DECLARE_FUNCTION(execRemoveFirstX);
	DECLARE_FUNCTION(execRemoveLastX);
	DECLARE_FUNCTION(execPopRandomX);
	DECLARE_FUNCTION(execPopRandomXFromStream);

};
