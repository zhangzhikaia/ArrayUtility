// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "ArrayUtilityBPLibrary.generated.h"


UCLASS()
class UArrayUtilityBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()
	
    /* Get First X elements (copy, keep order) */
    UFUNCTION(BlueprintCallable,CustomThunk,Category = "Array|Utility",
        meta = (DisplayName = "Get First X",
                ArrayParm = "TargetArray", 
                ArrayTypeDependentParams = "OutArray", 
                CompactNodeTitle = "FirstX"))
    static void GetFirstX(const TArray<int32>& TargetArray, int32 Count,TArray<int32>& OutArray);

    /* Get Last X elements (copy, keep order) */
    UFUNCTION(BlueprintCallable, CustomThunk, Category="Array|Utility",
        meta = (DisplayName="Get Last X",
                ArrayParm="TargetArray",
                ArrayTypeDependentParams="OutArray",
                CompactNodeTitle="LastX"))
    static void GetLastX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray);

	/* Get Min X elements (copy, keep order) */
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Get Mid X",
				ArrayParm = "TargetArray",
				ArrayTypeDependentParams = "OutArray",
				CompactNodeTitle = "MidX"))
	static void GetMidX(const TArray<int32>& TargetArray,int32 StartIndex, int32 Count,TArray<int32>& OutArray);
	
    /* Random pick X elements without replacement */
    UFUNCTION(BlueprintCallable, CustomThunk, Category="Array|Utility",
        meta = (DisplayName="Get Random X (No Repeat)",
                ArrayParm="TargetArray",
                ArrayTypeDependentParams="OutArray",
                CompactNodeTitle="RandX"))
    static void GetRandomX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray);

	/* Random pick X elements without replacement from stream*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Get Random X (No Repeat,From Stream)",
				ArrayParm = "TargetArray",
				ArrayTypeDependentParams = "OutArray",
				CompactNodeTitle = "RandX(S)"))
	static void GetRandomXFromStream(const TArray<int32>& TargetArray,UPARAM(ref) FRandomStream& RandomStream,int32 Count,TArray<int32>& OutArray);

	/* @param SplitIndex: will == OutFront.Num()[Length] */
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Split Array",
				ArrayParm = "TargetArray",
				ArrayTypeDependentParams = "OutFront,OutBack",
				CompactNodeTitle = "Split"))
	static void SplitArray(const TArray<int32>& TargetArray,int32 SplitIndex, TArray<int32>& OutFront,TArray<int32>& OutBack);

	/* Remove First X elements */
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Remove First X",
				ArrayParm = "TargetArray",
				CompactNodeTitle = "RemFirstX"))
	static void RemoveFirstX(UPARAM(ref) TArray<int32>& TargetArray,int32 Count);

	/* Remove Last X elements */
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Remove Last X",
				ArrayParm = "TargetArray",
				CompactNodeTitle = "RemLastX"))
	static void RemoveLastX(UPARAM(ref) TArray<int32>& TargetArray,	int32 Count);

	/* Random pick X elements , and remove from source array */
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Pop Random X",
				ArrayParm = "TargetArray",
				ArrayTypeDependentParams = "OutArray",
				CompactNodeTitle = "PopRandX"))
	static void PopRandomX(UPARAM(ref) TArray<int32>& TargetArray,int32 Count,TArray<int32>& OutArray);

	/* Random pick X elements , and remove from source array , from stream*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Array|Utility",
		meta = (DisplayName = "Pop Random X (By Stream)",
				ArrayParm = "TargetArray",
				ArrayTypeDependentParams = "OutArray",
				CompactNodeTitle = "PopRandX(S)"))
	static void PopRandomXFromStream(UPARAM(ref) TArray<int32>& TargetArray,UPARAM(ref) FRandomStream& RandomStream,int32 Count,TArray<int32>& OutArray);
	
	
    /* ===== Custom Thunks ===== */
    DECLARE_FUNCTION(execGetFirstX);
    DECLARE_FUNCTION(execGetLastX);
	DECLARE_FUNCTION(execGetMidX);
    DECLARE_FUNCTION(execGetRandomX);
	DECLARE_FUNCTION(execGetRandomXFromStream);
	DECLARE_FUNCTION(execSplitArray);
	DECLARE_FUNCTION(execRemoveFirstX);
	DECLARE_FUNCTION(execRemoveLastX);
	DECLARE_FUNCTION(execPopRandomX);
	DECLARE_FUNCTION(execPopRandomXFromStream);
	/*template<typename Func>
	static void ArrayHelper_Execute(FScriptArrayHelper& SourceHelper, FScriptArrayHelper& DestHelper, int32 Count, Func&& Operation)
	{
		int32 NumToCopy = FMath::Clamp(Count, 0, SourceHelper.Num());
		for (int32 i = 0; i < NumToCopy; ++i)
		{
			Operation(SourceHelper, DestHelper, i);
		}
	}*/
};
