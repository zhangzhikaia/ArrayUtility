// Copyright lurongjiu 2026 All Rights Reserved.

#include "ArrayUtilityBPLibrary.h"
#include "ArrayUtility.h"
#include "Net/Core/PushModel/PushModel.h"

#define P_GET_ARRAY_PRV(ArrayAddr,ArrayProp)\
Stack.MostRecentProperty = nullptr;\
Stack.StepCompiledIn<FArrayProperty>(NULL);\
void* ArrayAddr = Stack.MostRecentPropertyAddress;\
FArrayProperty* ArrayProp = CastField<FArrayProperty>(Stack.MostRecentProperty); \
if (!ArrayProp)\
{\
	Stack.bArrayContextFailed = true;\
	return;\
}

UArrayUtilityBPLibrary::UArrayUtilityBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
}

// 普通 C++ 路径（Blueprint 不会走这里）
void UArrayUtilityBPLibrary::GetFirstX(const TArray<int32>& TargetArray, int32 Count,TArray<int32>& OutArray)
{
	check(0);
}

void UArrayUtilityBPLibrary::GetLastX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray)
{
	check(0);
}

void UArrayUtilityBPLibrary::GetMidX(const TArray<int32>& TargetArray, int32 StartIndex, int32 Count,TArray<int32>& OutArray)
{
	check(0);
}

void UArrayUtilityBPLibrary::GetRandomX(const TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray)
{
	check(0);
}

void UArrayUtilityBPLibrary::GetRandomXFromStream(const TArray<int32>& TargetArray, UPARAM(ref) FRandomStream& RandomStream,int32 Count, TArray<int32>& OutArray)
{
	check(0);
}

void UArrayUtilityBPLibrary::SplitArray(const TArray<int32>& TargetArray, int32 SplitIndex, TArray<int32>& OutFront,TArray<int32>& OutBack)
{
	check(0);
}

void UArrayUtilityBPLibrary::RemoveFirstX(TArray<int32>& TargetArray, int32 Count)
{
	check(0);
}

void UArrayUtilityBPLibrary::RemoveLastX(TArray<int32>& TargetArray, int32 Count)
{
	check(0);
}

void UArrayUtilityBPLibrary::PopRandomX(TArray<int32>& TargetArray, int32 Count, TArray<int32>& OutArray)
{
	check(0);
}

void UArrayUtilityBPLibrary::PopRandomXFromStream(TArray<int32>& TargetArray, UPARAM(ref) FRandomStream& RandomStream, int32 Count,TArray<int32>& OutArray)
{
	check(0);
}

// 不会被 Blueprint 调用

// Blueprint VM 调用路径
DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetFirstX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	
	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		
		DestHelper.EmptyValues();
	
		const int32 Num = SourceHelper.Num();
		const int32 RealCount = FMath::Clamp(Count, 0, Num);
		if(RealCount > 0)
		{
			FProperty* InnerProp = OutArray->Inner;
			DestHelper.AddValues(RealCount);
			// ===== 逐个复制前 X 个元素 =====
			for (int32 i = 0; i < RealCount; ++i)
			{
				//const int32 NewIndex = DestHelper.AddValue();
				InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(i),SourceHelper.GetRawPtr(i));
			}
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetLastX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;

	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		
		DestHelper.EmptyValues();
		
		const int32 Num = SourceHelper.Num();
		const int32 RealCount = FMath::Clamp(Count, 0, Num);
		const int32 StartIndex = Num - RealCount;
		if(RealCount > 0)
		{
			FProperty* InnerProp = OutArray->Inner;
			//DestHelper.AddValues(RealCount);
			for (int32 i = StartIndex; i < Num; ++i)
			{
				const int32 NewIndex = DestHelper.AddValue();
				InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(NewIndex),SourceHelper.GetRawPtr(i));
			}
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetMidX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取X Count
	P_GET_PROPERTY(FIntProperty, StartIndex);
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	
	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		
		DestHelper.EmptyValues();
		
		const int32 Num = SourceHelper.Num();
	
		const int32 RealStartIndex = FMath::Clamp(StartIndex, 0, Num);
		const int32 MaxCopyCount   = Num - RealStartIndex;
		const int32 RealCount      = FMath::Clamp(Count, 0, MaxCopyCount);

		if(RealCount > 0)
		{
			FProperty* InnerProp = OutArray->Inner;
			DestHelper.AddValues(RealCount);
			for (int32 i = 0; i < RealCount; ++i)
			{
				const int32 SrcIndex = RealStartIndex + i;
				//const int32 NewIndex = DestHelper.AddValue();

				InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(i),SourceHelper.GetRawPtr(SrcIndex));
			}
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetRandomX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;

	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		DestHelper.EmptyValues();
		const int32 Num = SourceHelper.Num();
		
        const int32 RealCount = FMath::Clamp(Count, 0, Num);
        
        if (RealCount > 0)
        {
        	/* 生成 index 池 */
        	TArray<int32> Indices;
        	Indices.Reserve(Num);
        	for (int32 i = 0; i < Num; ++i)
        	{
        		Indices.Add(i);
        	}
        	
        	/* Fisher–Yates Shuffle（只洗前 X 次也行，这里全洗，清晰优先） */
        	for (int32 i = Num - 1; i > 0; --i)
        	{
        		const int32 SwapIndex = FMath::RandRange(0, i);
        		Indices.Swap(i, SwapIndex);
        	}
        	
        	FProperty* InnerProp = OutArray->Inner;
        	DestHelper.AddValues(RealCount);
        	/* 拷贝前 RealCount 个 */
        	for (int32 i = 0; i < RealCount; ++i)
        	{
        		const int32 SrcIndex = Indices[i];
        		//const int32 NewIndex = DestHelper.AddValue();
        		InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(i),SourceHelper.GetRawPtr(SrcIndex));
        	}
        }
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execGetRandomXFromStream)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取RandomStream
	P_GET_STRUCT_REF(FRandomStream, RandomStream);
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	
	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		DestHelper.EmptyValues();
		const int32 Num = SourceHelper.Num();
		
		const int32 RealCount = FMath::Clamp(Count, 0, Num);
		if (RealCount > 0)
		{
			/* 生成 index 池 */
			TArray<int32> Indices;
			Indices.Reserve(Num);
			for (int32 i = 0; i < Num; ++i)
			{
				Indices.Add(i);
			}
			
			for (int32 i = Num - 1; i > 0; --i)
			{
				const int32 SwapIndex = RandomStream.RandRange(0, i);
				Indices.Swap(i, SwapIndex);
			}

			FProperty* InnerProp = OutArray->Inner;
			DestHelper.AddValues(RealCount);
			/* 拷贝前 RealCount 个 */
			for (int32 i = 0; i < RealCount; ++i)
			{
				const int32 SrcIndex = Indices[i];
				//const int32 NewIndex = DestHelper.AddValue();
				InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(i),SourceHelper.GetRawPtr(SrcIndex));
			}
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execSplitArray)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	// ===== SplitIndex =====
	P_GET_PROPERTY(FIntProperty, SplitIndex);
	// ===== OutFront =====
	P_GET_ARRAY_PRV(OutFrontAddr, OutFront);
	// ===== OutBack =====
	P_GET_ARRAY_PRV(OutBackAddr, OutBack);
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	
	if(TargetAddr && OutFrontAddr && OutBackAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper FrontHelper(OutFront, OutFrontAddr);
		FScriptArrayHelper BackHelper(OutBack, OutBackAddr);

		FrontHelper.EmptyValues();
		BackHelper.EmptyValues();

		const int32 Num = SourceHelper.Num();
		if (Num > 0)
		{
			const int32 RealSplitIndex = FMath::Clamp(SplitIndex, 0, Num);
			
			for (int32 i = 0; i < RealSplitIndex; ++i)
			{
				const int32 NewIndex = FrontHelper.AddValue();
				OutFront->Inner->CopySingleValueToScriptVM(FrontHelper.GetRawPtr(NewIndex),SourceHelper.GetRawPtr(i));
			}
			
			for (int32 i = RealSplitIndex; i < Num; ++i)
			{
				const int32 NewIndex = BackHelper.AddValue();
				OutBack->Inner->CopySingleValueToScriptVM(BackHelper.GetRawPtr(NewIndex),SourceHelper.GetRawPtr(i));
			}
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execRemoveFirstX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	//需修改已有数组的,标记dirty
	MARK_PROPERTY_DIRTY(Stack.Object, TargetArray);
	
	if(TargetAddr)
	{
		FScriptArrayHelper ArrayHelper(TargetArray, TargetAddr);

		const int32 Num = ArrayHelper.Num();
		const int32 RemoveCount = FMath::Clamp(Count, 0, Num);
		if (RemoveCount > 0)
		{
			ArrayHelper.RemoveValues(0, RemoveCount);
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execRemoveLastX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	// ===== Count =====
	P_GET_PROPERTY(FIntProperty, Count);

	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	//需修改已有数组的,标记dirty
	MARK_PROPERTY_DIRTY(Stack.Object, TargetArray);
	
	if(TargetAddr)
	{
		FScriptArrayHelper ArrayHelper(TargetArray, TargetAddr);

		const int32 Num = ArrayHelper.Num();
		const int32 RemoveCount = FMath::Clamp(Count, 0, Num);
		if (RemoveCount > 0)
		{
			const int32 StartIndex = Num - RemoveCount;
			ArrayHelper.RemoveValues(StartIndex, RemoveCount);
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execPopRandomX)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	//需修改已有数组的,标记dirty
	MARK_PROPERTY_DIRTY(Stack.Object, TargetArray);

	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		DestHelper.EmptyValues();
		
		const int32 Num = SourceHelper.Num();

		const int32 RealCount = FMath::Clamp(Count, 0, Num);
		if (RealCount > 0)
		{
			FProperty* InnerProp = OutArray->Inner;
			DestHelper.AddValues(RealCount);
			int32 Remaining = RealCount;
			for(int32 i = 0; i < RealCount; ++i)
			{
				const int32 PickIndex = FMath::RandRange(0, Remaining - 1);
				//const int32 NewIndex = DestHelper.AddValue();
				InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(i),SourceHelper.GetRawPtr(PickIndex));
				SourceHelper.RemoveValues(PickIndex, 1);
				--Remaining;
			}
		}
	}
	
	//结束数组操作标记
	P_NATIVE_END;
}

DEFINE_FUNCTION(UArrayUtilityBPLibrary::execPopRandomXFromStream)
{
	//获取输入数组
	P_GET_ARRAY_PRV(TargetAddr,TargetArray)
	//获取RandomStream
	P_GET_STRUCT_REF(FRandomStream, RandomStream);
	//获取X Count
	P_GET_PROPERTY(FIntProperty, Count);
	//获取输出数组
	P_GET_ARRAY_PRV(OutAddr,OutArray)
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	//需修改已有数组的,标记dirty
	MARK_PROPERTY_DIRTY(Stack.Object, TargetArray);
	if(TargetAddr && OutAddr)
	{
		FScriptArrayHelper SourceHelper(TargetArray, TargetAddr);
		FScriptArrayHelper DestHelper(OutArray, OutAddr);
		DestHelper.EmptyValues();
		const int32 Num = SourceHelper.Num();

		const int32 RealCount = FMath::Clamp(Count, 0, Num);
		if (RealCount > 0)
		{
			FProperty* InnerProp = OutArray->Inner;
			DestHelper.AddValues(RealCount);
			int32 Remaining = RealCount;
			for(int32 i = 0; i < RealCount; ++i)
			{
				const int32 PickIndex = RandomStream.RandRange(0, Remaining - 1);
				//const int32 NewIndex = DestHelper.AddValue();
				InnerProp->CopySingleValueToScriptVM(DestHelper.GetRawPtr(i),SourceHelper.GetRawPtr(PickIndex));
				SourceHelper.RemoveValues(PickIndex, 1);
				--Remaining;
			}
		}
	}
		
	//结束数组操作标记
	P_NATIVE_END;
}